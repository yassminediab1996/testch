 @extends('admin.layouts.app_en')
@section('title')
    Add Prescription
@endsection
@section('content')
    @php
     $i=0;
    @endphp
   <form action="{{url('admin/prescription/add')}}" method="post" enctype="multipart/form-data">
      {{csrf_field()}}
    <div class="modal-body">
        
        <div class="form-group">
            <label class="control-label">doctor name</label>
            <div class="input-group">
                <span class="input-group-addon br br-light no-br"><i class="ti-user"></i></span>
                <input type="text" name="doctor_name" class="form-control no-bl" value="" required>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label">patient name</label>
            <div class="input-group">
                <span class="input-group-addon br br-light no-br"><i class="ti-user"></i></span>
                <input type="text" name="patient_name" class="form-control no-bl" value="" required>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label">patient aga</label>
            <div class="input-group">
                <span class="input-group-addon br br-light no-br"><i class="ti-user"></i></span>
                <input type="text" name="patient_age" class="form-control no-bl" value="" required>
            </div>
        </div>
        
         <div class="form-group">
            <label class="control-label">date</label>
            <div class="input-group">
                <span class="input-group-addon br br-light no-br"><i class="ti-user"></i></span>
                <input type="date" name="date" class="form-control no-bl" value="" required>
            </div>
        </div>
   
       <p id="getsection">
         To Add Drugs Click Here!
       </p>
       <div class="form-group col-md-12" >
          
            <div class="" id="drugname" >
                
            </div>
        </div>
 <br/>
<div id="rr"></div>
    </div>
<div class="modal-footer">

    <button class="btn btn-dark btn-flat" data-dismiss="modal" aria-label="Close">Cancel</button>
    <button class="btn gredient-btn" type="submit">Add</button>
</div>
</form>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script>
        var id = 0;
    $("p" ).click(function() {

      //  var c = $('<div style="margin-bottom: 10px;" class="col-md-12"><div class="row"><label class="control-label">Drug Name </label><div class="input-group  col-md-4"><input type="text"name="drug_name[]" placholder="drug name" class="form-control no-bl" value="" required/></div><label class="control-label">Drug Time </label><div class="input-group  col-md-4"><select multiple name="drug_time[]['+id+']" placholder="drug time"  class="form-control" required><option value="1" >am</option><option value="2" >pm</option> </select></div></div></div>');
        var c = $('<div style="margin-bottom: 10px;" class="col-md-12"><div class="row"><label class="control-label">Drug Name </label><div class="input-group  col-md-4"><input type="text"name="drug_name[]" placholder="drug name" class="form-control no-bl" value="" required/></div><label class="control-label">Drug Time </label><div class="input-group  col-md-4"><input type="text" placeholder="time" name="drug_time[]" ></div></div></div>');
        id = id +1;
        $('#drugname').append(c);
        });

    </script>
@endsection