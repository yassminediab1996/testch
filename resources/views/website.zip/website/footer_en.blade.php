<!-- End Content -->

<style>
    .smoke {
        color :white !important;
    }
    .smoke *{
             color :white !important;
    }
     	.list-social>a.twi:hover {
    color: #fff;
    border-color: #1DA1F2;
     background-color: #1DA1F2 !important;
}
.list-social>a.ins:hover {
    color: #fff;
    border-color: pink;
     background-color: pink !important;
}
	.list-social>a.lin:hover {
    color: #fff;
    border-color: #0077B5;
     background-color: #0077B5 !important;
}
	.list-social>a.you:hover {
    color: #fff;
    border-color: red;
     background-color: red !important;
}
..footer-copyright{
    padding:unset !important;
}
.newsletter-form input[type="submit"] {
       margin-top: -2px;

}
</style>
  <link href=“//cdn-images.mailchimp.com/embedcode/horizontal-slim-10_7.css” rel=“stylesheet” type=“text/css”>
    <style type="text/css">
                    	#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; width:100%;}
                    	/* Add your own Mailchimp form style overrides in your site stylesheet or in this style block.
                    	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
                    	   #mc_embed_signup {
                                background: unset;
                                clear: left;
                                 font: unset; 
                                width: 100%;
                            }
                            #mc_embed_signup input.email{
                                    margin-left: 130px;
                                    width:280px !important;
                            }
                    </style>
<div id="footer" >
    <div class="footer footer01" style="background-color: #62cb5d !important;">
        <div class="container">
            <div class="footer-list-box">
                <div class="row">
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="newsletter-form footer-box">
                         
                            <h2 class="title14 white">الإشتراك</h2>
                            <!--<form>-->
                            <!--    <input type="text" onblur="if (this.value=='') this.value = this.defaultValue" onfocus="if (this.value==this.defaultValue) this.value = ''" value="ادخل بريدك الالكترونى">-->
                            <!--    <input type="submit" value="إشتراك" style=" background-color: #4e9b4a !important;">-->
                            <!--</form>-->
                            
                                <div id="mc_embed_signup">
                                    <form action="https://chefaa.us18.list-manage.com/subscribe/post?u=0c607300b0650fa81e42606cd&amp;id=4a88bff1e7" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate"  novalidate>
                                        <div id="mc_embed_signup_scroll">
                                    	<input type="email" value="" name="EMAIL" class="email" style="    height: 33px;
" id="mce-EMAIL" placeholder="بريدك الإلكترونى " required>
                                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                        <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_0c607300b0650fa81e42606cd_3b3b6e768b" tabindex="-1" value=""></div>
                                        <div class="clear"><div class="clearfix"></div><input  style=" background-color: #4e9b4a !important;" type="submit" value="إشترك" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
                                        </div>
                                    </form>
                                </div>
                        
                        </div>
                        <div class="social-footer footer-box">
                          
                            <h2 class="title14 white">    كن على تواصل معنا</h2>
                        
                            <div class="list-social">
                                <a href="https://www.facebook.com/GetChefaa" class="white fac" target="_blank"><i class="fa fa-facebook" aria-hidden="true" target="_blank"></i></a>
                                <a href="https://www.twitter.com/getchefaa" class="white twi" target="_blank"><i class="fa fa-twitter" aria-hidden="true" target="_blank"></i></a>
                                <a href="https://www.linkedin.com/company/getchefaa" class="white lin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true" target="_blank"></i></a>
                                <a href="https://www.instagram.com/getchefaa/" class="white ins" target="_blank"><i class="fa fa-instagram" aria-hidden="true" target="_blank"></i></a>
                                <a href="#" class="white you" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-3 col-xs-6">
                        <div class="menu-footer-box footer-box">
                        
                            <h2 class="title14 white">كيفية الشراء</h2>
                            <ul class="list-unstyled">
                                <li><a href="{{url('register')}}" class="smoke">إنشاء حساب</a></li>
                                <li><a href="#" class="smoke">حماية المشتري</a></li>
                                <li><a href="#" class="smoke">دليل المستخدم الجديد</a></li>
                            </ul>
                        
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-3 col-xs-6">
                        <div class="menu-footer-box footer-box">
                      
                            <h2 class="title14 white">خدمة العملاء</h2>
                            <ul class="list-unstyled">
                                <li><a href="{{url('contact2')}}" class="smoke">الدعم الفنى</a></li>
                                <li><a href="{{url('blog')}}" class="smoke">المدونة</a></li>
                                <li><a href="{{url('/')}}" class="smoke">عن شفاء</a></li>
                                <li><a href="{{url('contact2')}}" class="smoke">تواصل معنا</a></li>
                            </ul>
                          
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="contact-footer-box footer-box">
                         
                           <h2 class="title14 white">تواصل عنا</h2>
                           <div>
                               <i class="fa fa-map-marker " aria-hidden="true" style="color: white;font-size: 40px;    margin-bottom: -30px; margin-right: -10px;"></i>
                                                              <p style="color: white; padding-right: 50px;margin-top: -30px;">
                                                                 شارع 151 مبنى 4 الدور التاسع شقة رقم 903 المعادى - القاهرة
                                                                  </p><br>

                            </div>
                            
                            <div>
                                 <i class="fa fa-mobile-phone" aria-hidden="true" style="color: white;font-size: 40px;    margin-bottom: -30px;    margin-right: -7px;"></i>
                                   <p style="color: white; padding-right: 50px;margin-top: -30px;"> 01000644422</p></br>
                            </div>
                            <div>
                                  <i class="fa fa-envelope" style="color: white;font-size: 33px;    margin-bottom: -30px;    margin-right: -15px;"></i>
                            <p style="color: white;    padding-right: 50px;margin-top: -30px;"><a href="mailto:email@demolink.org" class="smoke">info@chefaa.com</a></p>
                            </div>
                         
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer List Box -->
        </div>
       
        <!-- End Payment -->
        
        <!-- End Footer Tab -->
        <div class="footer-copyright" style="background-color: #4e9b4a !important;    height: 65px;
">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12">
                        <p class="copyright" style="margin-right: 480px;">    جميع الحقوق محفوظة لموقع شفاء.</p>
                    </div>
                 
                </div>
            </div>
        </div>
        <!-- End Footer Copyright -->
    </div>
</div>

	<a href="#" class="radius scroll-top style1"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script>
$(document).ready(function() {
      $("#mc-embedded-subscribe-form").submit(function() {
         swal({
              title: 'شكرا',
              text: "شكرا لتسجيلك معنا!",
          });
          
          $.getJSON('http://chefaa.com/cool-cats-optin/mc-end-point.php', formData ,function(data) {
			// uncomment next line to see your data output in console
			// console.log(data);
			
			// If it worked...
			if(data.status === 'subscribed') {
				// Let us know!
				alert('Thanks!');
			} else {
				// Otherwise tell us why it didn't
				alert("oops error: " + data.detail);
			}
		});
  });
});
</script>
<script src="{{asset('website/js/libs/jquery-3.2.1.min.js')}}"></script>
<script src="{{asset('website/js/libs/bootstrap.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.fancybox.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery-ui.min.js')}}"></script>
<script src="{{asset('website/js/libs/owl.carousel.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.jcarousellite.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.elevatezoom.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script src="{{asset('website/js/libs/timecircles.min.js')}}"></script>
<script src="{{asset('website/js/libs/popup.js')}}"></script>
<script src="{{asset('website/js/libs/wow.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script src="{{asset('website/js/libs/flipclock.min.js')}}"></script>
<script src="{{asset('website/js/theme.js')}}"></script>


<!-- Hotjar Tracking Code for www.chefaa.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- Hotjar Tracking Code for www.chefaa.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'vUqJL7ruiX';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
<!-- {/literal} END JIVOSITE CODE -->
</body>
</html>