<!DOCTYPE html>
<html data-wf-page="5c59e2f3e0aef9beb26758d5" data-wf-site="5c4e31307c1ca4e654061ac3">
<head>
  <meta charset="utf-8">
  <title>المسؤلية المجتمعية</title>
  <meta content="المسؤ" property="og:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

   <link href="//cdn-images.mailchimp.com/embedcode/horizontal-slim-10_7.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link href="{{asset('chefaa_design/css/normalize.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('chefaa_design/css/webflow.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('chefaa_design/css/chefaa.webflow.css')}}" rel="stylesheet" type="text/css">
   <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link rel="shortcut icon" href="{{asset('images/icon.png')}}" type="image/x-icon">
    <link rel="icon" href="{{asset('images/icon.png')}}" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" href="{{asset('images/icon.png')}}">
  
</head>
<style>
    a:hover {
    color: #f8f3f3;
}
   a:hover{
                                text-decoration: none;
                        }
.progress-bar {
   
    background-color: #e9ecef !important;
}



.pop-up-wrapper {
    position: fixed;
    left: 400px;
    top: 55px;
    right: 400px;
    bottom: 0px;
    z-index: 10000000;
    display: none;
    overflow: hidden;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    background-color: hsla(0, 0%, 100%, .7);
}
</style>
<body data-w-id="5c59e2f3e0aef912166758d7" class="body">
    
              <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-K7J9NT9');</script>
           <!-- Google Tag Manager -->
  
      <div class="formcsr fade modal " tabindex="-1" role="dialog" >
           <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title"> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
              </div>
   
            </div>
          </div>
        </div>
@include('website.notfi')
  <div data-collapse="medium" data-animation="default" data-duration="400" data-easing="ease-in-quad" data-easing2="ease-in-quad" class="navbar w-nav">
    <div class="navcontainer w-clearfix">
      <div class="menu-button w-nav-button">
        <div class="icon w-icon-nav-menu"></div>
      </div><a href="{{url('/')}}" class="brand w-nav-brand"><img src="{{asset('chefaa_design/images/logo.svg')}}" width="157" alt=""></a>
      <nav role="navigation" class="nav-menu w-nav-menu">
          <a href="{{url('contact')}}" class="navlink w-nav-link">تواصل معنا</a>
          <a href="{{url('blog')}}" class="navlink w-nav-link"> المدونة</a>
          <a href="{{url('/chefaa_app')}}" class="navlink w-nav-link">⚡️ تطبيق شفاء</a>
          <a href="{{url('search')}}" class="navlink w-nav-link">ابحث عن دواء</a>
          <a href="{{url('store')}}" class="navlink w-nav-link">المتجر</a>
          <a href="{{url('monthly_subscription')}}" class="navlink w-nav-link ">الروشتة الشهرية</a>
                      <a href="{{url('csr')}}" class="navlink w-nav-link w--current" >المسؤلية المجتمعية</a>
                      <p style="    float: right; position: relative; top: 60px;right: 175px;    font-size: 9px;color: green;font-weight: bold;">POWERED BY</p>

<img src="{{asset('uploads/files/logowe.png')}}" style="    position: relative;
    top: 55px;
    right: 65px;">
   
          </nav>
    </div>
  </div>
  <div class="head w-clearfix">
    <div class="csrcontainer w-clearfix">
      <h1 class="heading"><span class="text-span">اتبرع<br></span>و ساهم فى رسم الابتسامة على وش مريض محتاج<br></h1>
    </div>
    <div data-w-id="8418852e-af6c-c733-e374-4d0073606a40" class="div-block-3 w-clearfix">
      <a data-w-id="b209a2f9-2383-a4b2-1c1b-83bfa3d4d64f" href="#" class="adddonationbutton w-inline-block w-clearfix">
        <div class="plusicon"><img src="{{asset('chefaa_design/images/.svg')}}" alt=""></div>
        <div class="text-block-8">اضف حالة</div>
      </a>
    </div>

    <div data-w-id="09a4bd7b-0c5a-cfa7-80c1-5c3f44b56510" class="div-block csr">
      <ol class="list-3 w-list-unstyled">
        <li class="list-item-2 w-clearfix">
          <div class="number green"><strong class="bold-text-7">{{ $casecount }}</strong></div>
          <div class="text-block dark">عدد الحالات</div>
        </li>
        <li class="list-item-2 w-clearfix">
          <div class="number green"><strong class="bold-text-3">{{$amountcount}}</strong></div>
          <div class="text-block dark">مجموع التبرعات</div>
        </li>
      </ol>
    </div>
  </div>

  <div class="cases-section">
    <div class="w-layout-grid grid-3">
          @php
             $getqty=0;
            @endphp
            @foreach($caselist as $case)
              @foreach($case->userscase as $qtycase)
                 @if($qtycase->approval == 1)
                    @php
                      $getqty += $qtycase->qty;
                    @endphp
                   @endif 
              @endforeach
        @if($case->max_amount > $getqty)  
      <div  class="donation-card w-node-558e18fd4d92-b26758d5">
        <div  class="img">
            <img class="card-img-top" src="{{url('uploads/files/'.App\AdminModel\charity::find($case->charity_id)->img)}}" alt="Card image" style="width:100% ;height: 500px;">
        </div>
        <div  class="text-block-11">  
        تبرع لحالة
          {{$case->person}}
          تخص جمعية
          {{App\AdminModel\charity::find($case->charity_id)->name_ar}}
        </div>
        <div class="progress-bar w-clearfix">
          <div  class="value-progressbar" style="width:{{($getqty / $case->max_amount)*100}}%;" ></div>
        </div>
        <div class="text-block-13">{{$getqty}} / {{$case->max_amount}}</div><a onclick="openmodel({{$case->id}})" style="color: white;" class="cta w-button">اريد التبرع</a>
        </div>
    @endif
   @php
     $getqty=0;
    @endphp
    @endforeach
    </div>
  </div>
  <footer id="footer" class="footer w-clearfix">
    <div class="div-block footer">
      <div class="form-block-2 w-form">
        <form id="email-form" name="email-form" data-name="Email Form" class="form"><input type="email" class="textfield newsletter w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="..ادخل بريدك الالكتروني" id="email-2" required=""><input type="submit" value="ارسال" data-wait="..برجاء الانتظار" class="submit-button w-button"></form>
  
      </div>
      <div class="text-block-7">💌 لمتابعة الجديد من خلال البريد الإلكترونى</div>
    </div>
    <div class="footercontainer w-clearfix">
      <div class="social-icons"><a target="_blank" id="faacebook" href="https://www.facebook.com/GetChefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/fb.svg')}}" alt=""></a><a target="_blank" id="twitter" href="https://www.twitter.com/getchefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/twitter.svg')}}" alt=""></a><a target="_blank" id="instagram" href="https://www.instagram.com/getchefaa/" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/instagram.svg')}}" alt=""></a><a target="_blank" id="linkedin" href="https://www.linkedin.com/company/getchefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/linkedin.svg')}}" alt=""></a></div>
      <ol class="list w-list-unstyled">
        <li class="list-item"><a href="#" class="footer-link">تواصل معنا</a></li>
        <li class="list-item"><a href="#" class="footer-link">خدمات</a></li>
        <li class="list-item"><a href="#" class="footer-link">سياسة الخصوصية</a></li>
        <li><a href="#" class="footer-link">استفسارات</a></li>
      </ol>
    </div>
  </footer>
  <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
  <!-- model -->

    <script>
    $('document').ready(function () {     
        jQuery.noConflict();

    });
     function openmodel(id)
        {
              // $('.formcsr').modal();
            //  jQuery('.pop-up-wrapper').modal('show', {backdrop: 'true'});
                   $('.formcsr').modal("show"); 
              $.ajax({
                 type: "GET",
                 url: 'csr/send/' + id,
                 dataType: "html",
                 data: {
                 },
                success: function (response) {
                  jQuery('.formcsr .modal-body').html(response);
                },
                error: function (e) {
                  
                }
            });
        }
    </script>
     <!-- Hotjar Tracking Code for www.chefaa.com -->
    <script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
     <!-- Hotjar Tracking Code for www.chefaa.com -->
     <script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
      <!-- BEGIN JIVOSITE CODE {literal} -->
     <script type='text/javascript'>
(function(){ var widget_id = 'vUqJL7ruiX';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
     <!-- {/literal} END JIVOSITE CODE -->
     <!--<script src="https://d1tdp7z6w94jbb.cloudfront.net/js/jquery-3.3.1.min.js" type="text/javascript" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>-->
    <script src="{{asset('chefaa_design/js/webflow.js')}}" type="text/javascript"></script>
     <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
</html>