<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Tue Mar 05 2019 19:05:35 GMT+0000 (UTC)  -->
<html data-wf-page="5c4e31307c1ca431c3061ac4" data-wf-site="5c4e31307c1ca4e654061ac3">
<head>
  <meta charset="utf-8">
  <title>Chefaa</title>
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="{{asset('chefaa_design/css/normalize.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('chefaa_design/css/webflow.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('chefaa_design/css/chefaa.webflow.css')}}" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <!--<link href="https://daks2k3a4ib2z.cloudfront.net/img/favicon.ico" rel="shortcut icon" type="image/x-icon">-->
  <!--<link href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png" rel="apple-touch-icon">-->
  <link rel="icon" href="{{asset('images/icon.png')}}" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" href="{{asset('images/icon.png')}}">
     <link rel="shortcut icon" href="{{asset('images/icon.png')}}" type="image/x-icon">
</head>
<body class="body">
             <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K7J9NT9');</script>
  <div class="head">
    <div data-collapse="medium" data-animation="default" data-duration="400" data-easing="ease-in-quad" data-easing2="ease-in-quad" class="navbar w-nav">
      <div class="navcontainer w-clearfix">
        <div class="menu-button w-nav-button">
          <div class="icon w-icon-nav-menu"></div>
        </div><a href="{{url('/')}}" class="brand w-nav-brand w--current"><img src="{{asset('chefaa_design/images/logo.svg')}}" width="157" alt=""></a>
      <nav role="navigation" class="nav-menu w-nav-menu">
          <a href="{{url('contact')}}" class="navlink w-nav-link">تواصل معنا</a>
          <a href="{{url('blog')}}" class="navlink w-nav-link"> المدونة</a>
          <a href="{{url('/chefaa_app')}}" class="navlink w-nav-link">⚡️ تطبيق شفاء</a>
          <a href="{{url('search')}}" class="navlink w-nav-link">ابحث عن دواء</a>
          <a href="{{url('store')}}" class="navlink w-nav-link">المتجر</a>
          <a href="{{url('monthly_subscription')}}" class="navlink w-nav-link ">الروشتة الشهرية</a>
          <a href="#" class="navlink w-nav-link">المسؤلية المجتمعية</a>
       
          </nav>
      </div>
    </div>
    <div class="headcontainer w-clearfix"><img src="{{asset('chefaa_design/images/topIllustration.svg')}}" data-w-id="d34c8cde-fe26-2a84-b0f8-97694f5c31be" alt="" class="headillustration">
      <div class="text-head-container w-clearfix">
        <h1 class="heading">خدمة <span><strong class="spain">شفاء</strong></span> الخدمة الأسهل في طلب الدواء</h1>
        <p class="phead">الأن تستطيع طلب دوائك بكل سهولة ويسر من خلال تطبيق شفاء مع<br>.إمكانية حجز دوائك الشهري ليصلك آينما كنت</p>
        <div class="storecontainer"><a target="_blank" href="https://play.google.com/store/apps/details?id=app.com.chefaa&hl=ar" class="storebutton w-inline-block"><img src="{{asset('chefaa_design/images/googlePlay.svg')}}" class="playstore_home" alt=""></a><a target="_blank" href="https://itunes.apple.com/eg/app/chefaa-medicine-delivery/id1438961456?mt=8" class="storebutton w-inline-block"><img src="{{asset('chefaa_design/images/appStore.svg')}}" class="appstore_home" alt=""></a></div>
      </div>
    </div>
  </div>
  <div class="servicessec">
    <div class="whitebg">
      <div class="servicesrow w-row">
        <div class="servicescol w-col w-col-3 w-col-medium-6"><img src="{{asset('chefaa_design/images/makeup.svg')}}" alt="" class="icon_service">
          <div class="servicetitle"><strong>شركات مستحضرات التجميل</strong></div><a href="http://سس" class="service_more_button beauty w-inline-block"><img src="{{asset('chefaa_design/images/arrow-left--green.svg')}}" alt=""><div>المزيد</div></a></div>
        <div class="servicescol w-col w-col-3 w-col-medium-6"><img src="{{asset('chefaa_design/images/medicine.svg')}}" alt="" class="icon_service">
          <div class="servicetitle"><strong> شركات الأدوية </strong></div><a href="#" class="service_more_button medicine w-inline-block"><img src="{{asset('chefaa_design/images/arrow-left--green.svg')}}" alt=""><div>المزيد</div></a></div>
        <div data-w-id="94b411f7-7dcf-6ca3-61bb-b7544fb8abcc" class="servicescol w-col w-col-3 w-col-medium-6"><img src="{{asset('chefaa_design/images/insurance.svg')}}" alt="" class="icon_service">
          <div class="servicetitle"><strong> شركات التأمين</strong></div><a data-w-id="4ee0b496-8fbe-6299-5913-4d9045ba37ae" href="#" class="service_more_button insuraance w-inline-block"><img src="{{asset('chefaa_design/images/arrow-left--green.svg')}}" alt=""><div>المزيد</div></a></div>
        <div data-w-id="94b411f7-7dcf-6ca3-61bb-b7544fb8abcd" class="servicescol w-col w-col-3 w-col-medium-6"><img src="{{asset('chefaa_design/images/institue.svg')}}" alt="" class="icon_service">
          <div class="servicetitle"><strong>المؤسسات</strong></div><a data-w-id="33bc4fa0-a8b9-392c-30ee-c5ec96a01b27" href="#" class="service_more_button institution w-inline-block"><img src="{{asset('chefaa_design/images/arrow-left--green.svg')}}" alt=""><div>المزيد</div></a></div>
      </div>
    </div>
    <div class="b2c-container">
      <h2 class="sectitle center"><strong>مميزات تطبيق شفاء</strong></h2>
      <div class="w-layout-grid b2cgrid">
        <div id="w-node-6dd84368b877-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/remind.svg')}}" alt=""></div>
          <h4 class="h4"><strong class="bold-text-4">تذكير دوائي</strong></h4>
          <p class="paragraph">مكانية تذكيرك بمواعيد الأدوية من خلال رسائل نصية بالمواعيد التي تحددها.<br></p>
        </div>
        <div id="w-node-3fb51ee378a7-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/payment.svg')}}" alt=""></div>
          <h4 class="h4"><strong>الدفع الإلكترونى</strong></h4>
          <p class="paragraph">إمكانية الدفع من خلال البطاقة الإئتمانية بكل سرية وأمان.<br></p>
        </div>
        <div id="w-node-e0ff1b99394e-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/search.svg')}}" alt=""></div>
          <h4 class="h4"><strong class="bold-text">  البحث عن الأدوية</strong></h4>
          <p class="paragraph">   محرك بحث تستطيع من خلاله إيجاد أماكن توافر الدواء بعيدا عن مشاكل البحث المعتاده<br></p>
        </div>
        <div id="w-node-21e39173e083-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/delivery.svg')}}" alt=""></div>
          <h4 class="h4"><strong>توصيل الأدوية</strong></h4>
          <p class="paragraph">توصيل الأدوية من أقرب صيدلية بسهولة ويسر دقة.<br></p>
        </div>
        <div id="w-node-b964efb4c094-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/alert.svg')}}" alt=""></div>
          <h4 class="h4"><strong>تنبيهات النواقص</strong></h4>
          <p class="paragraph">إرسال تنبيهات بنواقص الأدوية الثابتة لأصحاب الأمراض المزمنة<br></p>
        </div>
        <div id="w-node-94d5224923e2-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/archive.svg')}}" alt=""></div>
          <h4 class="h4"><strong>أرشيف الطلبات</strong></h4>
          <p class="paragraph">ارشيف كامل لكل طلباتك السابقة يساعدك علي متابعة حالتك.<br></p>
        </div>
        <div id="w-node-30fe83538f05-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/offer.svg')}}" alt=""></div>
          <h4 class="h4"><strong>العروض والخصومات</strong></h4>
          <p class="paragraph">إمكانية الوصول لكل العروض والخصومات الخاصة بجميع المنتجات الغير دوائية.<br></p>
        </div>
        <div id="w-node-11f4209d2f67-c3061ac4" class="b2c-card">
          <div class="b2c-icon"><img src="{{asset('chefaa_design/images/pckgs.svg')}}" alt=""></div>
          <h4 class="h4"><strong>الباقات الشهرية</strong></h4>
          <p class="paragraph">إمكانية التوصيل الشهري للأدوية بعيدا عن مشاكل نقص الأدوية.<br></p>
        </div>
      </div>
    </div>
  </div>
  <div class="numberssection">
    <div class="numberscontainer">
      <h2 class="sectitle right w-clearfix"><strong>  شفاء فى أرقام</strong></h2>
      <div class="numbersrow w-row">
        <div class="numberscol w-clearfix w-col w-col-3 w-col-medium-6">
          <div class="number"><strong class="bold-text-3">+10000</strong></div>
          <div class="numberslabel">
            <div class="text-block">طلب</div><img src="{{asset('chefaa_design/images/users.svg')}}" alt=""></div>
        </div>
        <div class="numberscol w-clearfix w-col w-col-3 w-col-medium-6">
          <div class="number"><strong class="bold-text-3">+700</strong></div>
          <div class="numberslabel">
            <div class="text-block">عميل</div><img src="{{asset('chefaa_design/images/clients.svg')}}" alt=""></div>
        </div>
        <div class="numberscol w-clearfix w-col w-col-3 w-col-medium-6">
          <div class="number"><strong class="bold-text-3">+8000</strong></div>
          <div class="numberslabel">
            <div class="text-block">زائر</div><img src="{{asset('chefaa_design/images/userss.svg')}}" alt=""></div>
        </div>
        <div class="numberscol w-clearfix w-col w-col-3 w-col-medium-6">
          <div class="number"><strong class="bold-text-3">+1000</strong></div>
          <div class="numberslabel">
            <div class="text-block">تحميل</div><img src="{{asset('chefaa_design/images/download.svg')}}" width="20" alt=""></div>
        </div>
      </div>
    </div>
  </div>
  <div class="testimonials-section w-clearfix">
    <div class="div-block"><img src="{{asset('chefaa_design/images/testmonials.svg')}}" alt="" class="image">
      <div class="the-overflow-hidden-mask">
        <div class="the-width-400vh-scrollable-div">
          <div class="the-content-2">
            <div class="a-block">
              <div class="testimonial-card-head">
                <div class="testimonial-card-head-text">
                  <div id="username" class="text-block-3">سلمى ابراهيم</div>
                  <!--<div id="user-position" class="text-block-4">CEO of Whatever</div>-->
                </div>
                <div class="avatar"></div>
              </div>
              <p class="paragraph">
شكرا ليكم بابا جرب الخدمة 3 مرات وكل مرة كنتوا بتساعدونا نوصل للدوا سريعا
                  </p>
            </div>
            <div class="a-block">
              <div class="testimonial-card-head">
                <div class="testimonial-card-head-text">
                  <div id="username" class="text-block-3"> احمد متولى</div>
                  <!--<div id="user-position" class="text-block-4">CEO of Whatever</div>-->
                </div>
                <div class="avatar"></div>
              </div>
              <p class="paragraph">
كان في دوا كنت دايخ عليه وعرفت الاقيه من خلال التطبيق
                  </p>
            </div>
            <div class="a-block">
              <div class="testimonial-card-head">
                <div class="testimonial-card-head-text">
                  <div id="username" class="text-block-3"> احمد عبدالرحيم</div>
                  <!--<div id="user-position" class="text-block-4">CEO of Whatever</div>-->
                </div>
                <div class="avatar"></div>
              </div>
              <p class="paragraph">
application that any one should have easy to use and fast delivery
                  </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="media-section">
    <h2 class="sectitle center"><strong>شفاء في الميديا</strong></h2>
    <div class="w-layout-grid grid">
      <div id="media-card" class="media-card w-node-4adc45857083-c3061ac4 w-clearfix">
        <div id="media-card-timage" class="media-card-image">
            	<a target="_blank" href="https://youtu.be/ofzFgqQSi6A">
						<img  src="{{asset('landingpage/images/4-hona-alshabab.png')}}" style="    margin-left: 60px;" alt="press-logo" />
				</a>
        </div>
        <div id="media-card-title" class="text-block-5">هنا الشباب | المشروع الفائز في الحلقة الثالثة &quot;مام - فرابيوتك - شفاء&quot;</div>
      </div>
      <div id="media-card" class="media-card w-node-97f44f54fe1b-c3061ac4 w-clearfix">
        <div id="media-card-timage" class="media-card-image">
            	<a target="_blank" href="http://weetracker.com/2018/07/20/ehealth-startup-chefaa-wins-egyptian-leg-of-demo-africa-innovation-tour/">
					<img style="    margin-left: 60px;" src="{{asset('landingpage/images/8-we-tracker.png')}}" alt="press-logo" />
				</a>
        </div>
        <div id="media-card-title" class="text-block-5">Startup Chefaa Wins Egyptian Leg Of DEMO Africa Innovation Tour</div>
      </div>
      <div id="media-card" class="media-card w-node-87692fe3e473-c3061ac4 w-clearfix">
        <div id="media-card-timage" class="media-card-image">
            	<a target="_blank" href="http://ik.ahram.org.eg/News/47348.aspx">
						<img  src="{{asset('landingpage/images/2al-ahram.png')}}"  style="    margin-left: 60px;" alt="press-logo" />
				</a>
        </div>
        <div id="media-card-title" class="text-block-5">الاهرام | تطبيق شفاء يفوز بمسابقة نواة فى الابداع والابتكار فى البرمجيات!</div>
      </div>
      <div id="media-card" class="media-card w-node-dfe93fa8a567-c3061ac4 w-clearfix">
        <div id="media-card-timage" class="media-card-image">
            	<a target="_blank" href="https://www.youtube.com/watch?v=UgCIfhdxYNU">
					<img  src="{{asset('landingpage/images/1onlive.png')}}" style="    margin-left: 60px;" alt="press-logo" />
				</a>
        </div>
        <div id="media-card-title" class="text-block-5">اون تي ڤي | دعاء عارف تبتكر تطبيق شفاء يسمح بسرعة وصول الدواء للمرضي.</div>
      </div>
      <div id="media-card" class="media-card w-node-3559705b3990-c3061ac4 w-clearfix">
        <div id="media-card-timage" class="media-card-image">
            	<a target="_blank" href="https://www.crunchbase.com/organization/chefaa">
					<img style="    margin-left: 100px;" src="{{asset('landingpage/images/6-crunchbase.png')}}" alt="press-logo" />
				</a>
        </div>
        <div id="media-card-title" class="text-block-5">Chefaa On Startup Scene</div>
      </div>
      <div id="media-card" class="media-card w-node-0d2db2bf2041-c3061ac4 w-clearfix">
        <div id="media-card-timage" class="media-card-image">
            	<a target="_blank" href="http://www.startupsceneme.com/INVESTMENTS/9-Egyptian-Startups-Attend-London-Tech-Week-With-UK-Embassy">
					<img style="    margin-left: 100px;" src="{{asset('landingpage/images/5-the-startup-scene.png')}}" alt="press-logo" />
				</a>
        </div>
        <div id="media-card-title" class="text-block-5">Chefaa On CrunchBase</div>
      </div>
    </div>
  </div>
  <footer id="footer" class="footer w-clearfix">
    <div class="div-block footer">
      <div class="form-block-2 w-form">
        <form id="email-form" name="email-form" data-name="Email Form" class="form"><input type="email" class="textfield newsletter w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="..ادخل بريدك الالكتروني" id="email-2" required=""><input type="submit" value="ارسال" data-wait="..برجاء الانتظار" class="submit-button w-button"></form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
      <div class="text-block-7">💌 لمتابعة الجديد من خلال البريد الإلكترونى</div>
    </div>
    <div class="footercontainer w-clearfix">
      <div class="social-icons"><a target="_blank" id="faacebook" href="https://www.facebook.com/GetChefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/fb.svg')}}" alt=""></a><a target="_blank" id="twitter" href="https://www.twitter.com/getchefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/twitter.svg')}}" alt=""></a><a target="_blank" id="instagram" href="https://www.instagram.com/getchefaa/" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/instagram.svg')}}" alt=""></a><a target="_blank" id="linkedin" href="https://www.linkedin.com/company/getchefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/linkedin.svg')}}" alt=""></a></div>
      <ol class="list w-list-unstyled">
        <li class="list-item"><a href="#" class="footer-link">تواصل معنا</a></li>
        <li class="list-item"><a href="#" class="footer-link">خدمات</a></li>
        <li class="list-item"><a href="#" class="footer-link">سياسة الخصوصية</a></li>
        <li><a href="#" class="footer-link">استفسارات</a></li>
      </ol>
    </div>
  </footer>
  <script src="https://d1tdp7z6w94jbb.cloudfront.net/js/jquery-3.3.1.min.js" type="text/javascript" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="{{asset('chefaa_design/js/webflow.js')}}" type="text/javascript"></script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'vUqJL7ruiX';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
</html>