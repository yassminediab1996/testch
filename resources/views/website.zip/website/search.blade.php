@php $currentPage = 'search'; @endphp

@extends('website.layouts.header')

@section('title')
   محرك البحث-شفاء
@endsection
@section('style')
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

   <link href="//cdn-images.mailchimp.com/embedcode/horizontal-slim-10_7.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

           <style type="text/css">
        	#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; width:100%;}
        	/* Add your own Mailchimp form style overrides in your site stylesheet or in this style block.
        	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
        	   #mc_embed_signup {
                    background: unset;
                    clear: left;
                     font: unset; 
                    width: 100%;
                }
                #mc_embed_signup input.email{
                        margin-left: 130px;
                        width:280px !important;
                }
             
                 #mc_embed_signup .button {
                    float: left !important;
                    font-size: 17px;
                    border: none;
                    -webkit-border-radius: 3px;
                    -moz-border-radius: 3px;
                    border-radius: 8px;
                    letter-spacing: .03em;
                    color: #fff;
                    background-color: hsla(131.42857142857144, 53.85%, 45.88%, 1.00) !important;
                    box-sizing: border-box;
                    height: 50px;
                    line-height: 32px;
                    padding: 0 18px;
                    display: inline-block;
                    /* margin: 0; */
                    transition: all 0.23s ease-in-out 0s;
                    margin-top: -50px !important;
                    margin-left: -170px !important;
                        }
                        
                        a:hover{
                                text-decoration: none;
                        }
           </style>

@endsection
@section('content')
       <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">     إرسال بيناتك للتواصل معك </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                <div class="modal-body">
       
                </div>
              </div>
         </div>
       </div>

  <div class="search-engine-wrapper w-clearfix">
      
      @include('website.notfi')
    <form  class="search w-form">
        <input type="search" class="textfield search-text w-input" autofocus="true" maxlength="256" name="query" placeholder="..اكتب اسم الدواء" id="search" required="">
        <input type="button" onclick="openmodel()" value="بحث" class="cta w-button">
        </form>
    <h1 class="heading-5"><strong class="bold-text-9">2 نتيحة بحث ل “Panadol”</strong></h1>
  </div>
    @section('mailchimb')
      <div class="div-block footer">
      <div class="form-block-2 w-form">
        <!--<form id="email-form" name="email-form" data-name="Email Form" class="form">-->
        <!--    <input type="email" class="textfield newsletter w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="..ادخل بريدك الالكتروني" id="email-2" required="">-->
        <!--    <input type="submit" value="ارسال" data-wait="..برجاء الانتظار" class="submit-button w-button">-->
        <!--</form>-->
        <div id="mc_embed_signup">
            <form action="https://chefaa.us18.list-manage.com/subscribe/post?u=0c607300b0650fa81e42606cd&amp;id=3b3b6e768b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate form"  novalidate>
               <div id="mc_embed_signup_scroll">
                    <input type="email" class="textfield newsletter w-input" maxlength="256" name="EMAIL" class="email textfield newsletter w-input" id="mce-EMAIL" data-name="Email 2" placeholder=" ...إدخل بريدك الإلكترونى  " required="">
                    <input type="submit" value="ارسال" data-wait="..برجاء "  name="subscribe" id="mc-embedded-subscribe" class="button submit-button w-bu ">
                </div>
              </form>
        </div>
                        
                        <!--End mc_embed_signup-->
      </div>
      <div class="text-block-7">💌 لمتابعة الجديد من خلال البريد الإلكترونى</div>
    </div>
    @endsection
     <script>
$('document').ready(function () {     
        jQuery.noConflict();

    $('#search').keypress(function(event) {
        if(event.which == 13) { // 13 is the 'Enter' key
         
         var search = $( "#search" ).val();
        //  jQuery('#exampleModalCenter').modal('show', {backdrop: 'false'});
            $('#exampleModalCenter').modal('show');
                  $.ajax({
                     type: "GET",
                     url: 'sendsearch/'+ search ,
                     dataType: "html",
                     data: {
                     },
                    success: function (response) {
                      jQuery('#exampleModalCenter .modal-body').html(response);
                    },
                    error: function (e) {
                   
                    }
                });
          return false;
       }
    });
});
</script>
     <script>
    
        function openmodel()
        {
           
            var search = $( "#search" ).val();

        //     jQuery('#exampleModalCenter').modal('show', {backdrop: 'true'});
              $('#exampleModalCenter').modal();

              $.ajax({
                 type: "GET",
                 url: 'sendsearch/'+ search ,
                 dataType: "html",
                 data: {
                 },
                success: function (response) {
                   jQuery('#exampleModalCenter .modal-body').html(response);
                },
                error: function (e) {
                  
                }
            });
        }
    </script>

  @endsection