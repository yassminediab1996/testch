<html !DOCTYPE>
        <head>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

    </head>
        <style>
        body {
    background-color: #e9ebee;
}
	body{
	    
	    font-family : Tajawal !important;
	    
	}
.card {
    margin-top: 1em;
    webkit-box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
    box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
}

/* IMG displaying */
.person-card {
    margin-top: 5em;
    padding-top: 5em;
}
.person-card .card-title{
    text-align: center;
}
.person-card .person-img{
    width: 10em;
    position: absolute;
    top: -5em;
    left: 50%;
    margin-left: -5em;
    border-radius: 100%;
    overflow: hidden;
    background-color: white;
}
    </style>
  
    <body style="background-color: white;">
        @php
         $numbers = [1,2,3,4,5,6];
         shuffle($numbers);
         $var = 1;
         $sum=0; 
        $user = App\UserQuize::orderBy('created_at', 'desc')->first();
       
        $questions = App\UserQuestion::where('user_id' , $user->id)->get(); 
       
        foreach($questions as $question)
        {
        $score = App\QuizeScore::where(['qoption' => $question->answer_id , 'question_id' => $question->ques_id])->first();

        $sum +=  $score['precentage'];
        
        }
        $sum = (int) ( $sum /7); 
        @endphp
        <!--
         <div class="row justify-content-md-center">
                  <div class="col-md-12 mt-5 text-center">
                   <h1>Your score is : {{$sum}} % </h1>
                 </div> 
            </div>
            -->
         <div class="row justify-content-md-center">
                  <div class="col-md-12 mt-5 text-center">
                   <h1>
تهانينا ..اختر هديتك الان 
                   </h1>
                 </div> 
            </div>
            
        <div class="container">
            <div style="max-width: 750px;margin: auto; padding: 25px;">
            <div class="row justify-content-md-center">
                
    
   
                @foreach($numbers as $num)
                <div class="col-md-4" style="margin-bottom: 5px">
                    <button class="btn btn-success btn-md btn-block" onclick="getgift({{$num}})">
                     <i class="fas fa-gift fa-3x"></i>
                    <h4>افتح الأن</h4></button>
                </div>
                @php $var++; @endphp
               @endforeach
            </div>
            </div>
              <div class="row justify-content-md-center">
              <a href="{{url('quize')}}" class="justify-content-md-center btn btn-success mt-4">ابدء من جديد</a>  
              </div>
            </div>
        </div>
    </body>
    
    <div class="modal" tabindex="-1" role="dialog" id="gift">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" style="    margin-left: 120px;
">Modal title</h5>

           
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" style="height:100px">
            
            
          </div>
    
        </div>
      </div>
    </div>
      <script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
        function getgift(id)
        {
             
               $.get("{{ url('gitgist') }}?id="+id, function(data, status) {
                  console.log(data)
                 var img = "<img src='uploads/files/"+ data.img +"' class='img-responsive center-block'>";
                 var code = "<h2 class='center-block' style='margin-left:195px;'>"+ data.img +"</h2>";
                 var code = "<button class='btn btn-success btn-lg' style='margin-left:189px'>"+data.img+"</button>"

//                   $('#gift .modal-body').html(data.name + img);
                   $('#gift .modal-body').html(code);
                   $('#gift .modal-title').html(data.name);
                });
                 $('#gift').modal('show');
              
        }
    </script>
    </html>