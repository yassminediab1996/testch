<html !DOCTYPE>
        <head>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
        <style>
        body {
    background-color: #e9ebee;
}
	body{
	    
	    font-family : Tajawal !important;
	    
	}
.card {
    margin-top: 1em;
    webkit-box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
    box-shadow: 0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12);
}

/* IMG displaying */
.person-card {
    margin-top: 5em;
    padding-top: 5em;
}
.person-card .card-title{
    text-align: center;
}
.person-card .person-img{
    width: 10em;
    position: absolute;
    top: -5em;
    left: 50%;
    margin-left: -5em;
    border-radius: 100%;
    overflow: hidden;
    background-color: white;
}
  @php
  $Selected = 0;
  @endphp
    </style>
        <body style="    background-color: white;">
        <div class="container">
                @foreach($questions as $qus) 
            @php
              $getqes = App\Quize::find($qus->ques_id);
            @endphp
            <div class="row justify-content-md-center">
                  <div class="col-md-12 mt-5 text-center">
                    
                   <h1>{{$getqes->question }} </h1>
                 </div> 
            </div>
            @php
              $Selected = $qus->answer_id;
            @endphp
            <div class="row justify-content-md-center">
                <div class="col-md-4">
                 <div class="card" style="margin: 10% 30px;">
                        <div class="card-body text-center">
                             <div>
                                <img src="{{asset('uploads/files/'.$getqes->option1)}}" class="img-responsive center-block" style="max-width:100%;">
                             </div>
                             @if ($qus->answer_id == 1)
                                 <button type="button" class="btn btn-danger mt-4" onclick="choseqes(1,{{$getqes->id}})">تم الأختيار</button>
                            @else 
                                 <button type="button" class="btn btn-success mt-4" onclick="choseqes(1,{{$getqes->id}})">أختر</button>
                            @endif
                        </div>
                </div>
                </div>
                <div class="col-md-4">
                  <div class="card" style="margin: 10% 30px;">
                        <div class="card-body text-center">
                             <div>
                                 <img src="{{asset('uploads/files/'.$getqes->option2)}}" class="img-responsive center-block" style="max-width:100%;">
                                 
                             </div>
                             @if ($qus->answer_id == 2)
                                 <button type="button" class="btn btn-danger mt-4" onclick="choseqes(2,{{$getqes->id}})">تم الأختيار</button>
                            @else 
                                 <button type="button" class="btn btn-success mt-4" onclick="choseqes(2,{{$getqes->id}})">أختر</button>
                            @endif
                        </div>     
                 </div>
                 </div>
                 <div class="col-md-4">
                  <div class="card" style="margin: 10% 30px;">
                        <div class="card-body text-center">
                             <div >
                                 <img src="{{asset('uploads/files/'.$getqes->option3)}}"  style=" max-width:100%;">
                                 
                             </div>
                             @if ($qus->answer_id == 3)
                                 <button type="button" class="btn btn-danger mt-4" onclick="choseqes(3,{{$getqes->id}})">تم الأختيار</button>
                            @else 
                                 <button type="button" class="btn btn-success mt-4" onclick="choseqes(3,{{$getqes->id}})">أختر</button>
                            @endif
                        </div>
                   </div> 
                   </div>
                </div>
            @endforeach
            {{$questions->links('vendor.pagination.pagination')}}
            @if ($questions->currentPage() == 7)
            <div class="row justify-content-md-center giftbtn" style="visibility : hidden;">
              <a href="{{url('viewbutton')}}" class="justify-content-md-center btn btn-success"> أحصل على هديتك الأن</a>  
            </div>
              <br/><br/>

            @endif
        </div>
     
    </body>
        <script>
        var nextBtn = document.getElementsByClassName("pull-right")[0];
        var backBtn = document.getElementsByClassName("pull-left")[0];
        function choseqes(id,qid)
        {
            console.log(id)
            console.log(qid)
               $.get("{{ url('choseqes') }}?id="+id+'&qid='+qid, function(data, status) {
                   if(data == 1)
                   nextBtn.style.visibility = "visible";
                   location.reload();
                });
        }
        // URLs images
        var female_img = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSo8PcCxh7tT6MDFhJi2UaAT9SeciHqvZuaWtGg0y0-yyP8rMDz";
        var male_img = "https://visualpharm.com/assets/217/Life%20Cycle-595b40b75ba036ed117d9ef0.svg";
        
        // On page loaded
        $( document ).ready(function() {
            // Set the sex image
            set_sex_img();
            
            // Set the "who" message
            set_who_message();
        
            // On change sex input
            $("#input_sex").change(function() {
                // Set the sex image
                set_sex_img();
                set_who_message();
            });
        
            // On change fist name input
            $("#first_name").keyup(function() {
                // Set the "who" message
                set_who_message();
                
                if(validation_name($("#first_name").val()).code == 0) {
                    $("#first_name").attr("class", "form-control is-invalid");
                    $("#first_name_feedback").html(validation_name($("#first_name").val()).message);
                } else {
                    $("#first_name").attr("class", "form-control");
                }
            });
        
            // On change last name input
            $("#last_name").keyup(function() {
                // Set the "who" message
                set_who_message();
                
                if(validation_name($("#last_name").val()).code == 0) {
                    $("#last_name").attr("class", "form-control is-invalid");
                    $("#last_name_feedback").html(validation_name($("#last_name").val()).message);
                } else {
                    $("#last_name").attr("class", "form-control");
                }
            });
        });
        
        /**
        *   Set image path (Mr. or Ms.)
        */
        function set_sex_img() {
            var sex = $("#input_sex").val();
            if (sex == "Mr.") {
                // male
                $("#img_sex").attr("src", male_img);
            } else {
                // female
                $("#img_sex").attr("src", female_img);
            }
        }
        
        /**
        *   Set "who" message
        */
        function set_who_message() {
            var sex = $("#input_sex").val();
            var first_name = $("#first_name").val();
            var last_name = $("#last_name").val();
            
            if (validation_name(first_name).code == 0 || 
                validation_name(last_name).code == 0) {
                // Informations not completed
                $("#who_message").html("Who are you ?");
            } else {
                // Informations completed
                $("#who_message").html(sex+" "+first_name+" "+last_name);
            }
        }
        
        /**
        *   Validation function for last name and first name
        */
        function validation_name (val) {
            if (val.length < 2) {
                // is not valid : name length
                return {"code":0, "message":"The name is too short."};
            }
            if (!val.match("^[a-zA-Z\- ]+$")) {
                // is not valid : bad character
                return {"code":0, "message":"The name use non-alphabetics chars."};
            }
            
            // is valid
            return {"code": 1};
        }
        
        
    </script>
     @if($Selected ==0)
        <script>
           nextBtn.style.visibility = "hidden";
        </script>
     @else
        <script>
           nextBtn.style.visibility = "visible";
        </script>
     @endif
     @if($Selected !=0 && $questions->currentPage() == 7)
         <script>
           var giftBtn = document.getElementsByClassName("giftbtn")[0];
           giftBtn.style.visibility = "visible";
           nextBtn.style.visibility = "hidden";
           backBtn.style.visibility = "hidden";

        </script>
     @endif     
       <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</html>    
    