@php $currentPage = 'monthly_subscription'; @endphp

@extends('website.layouts.header')

@section('title')
  الروشتة الشهرية-شفاء
@endsection
@section('style')
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->

        <link href="{{asset('chefaa_design/dist/css/datepicker.min.css')}}" rel="stylesheet" type="text/css">
        <script src="{{asset('chefaa_design/dist/js/datepicker.min.js')}}"></script>

        <!-- Include English language -->
        <script src="{{asset('chefaa_design/dist/js/i18n/datepicker.en.js')}}"></script>
        <style>
           .w-input[readonly]{
                   background-color:#f2f6fa !important;
           }
        </style>
           <link href="//cdn-images.mailchimp.com/embedcode/horizontal-slim-10_7.css" rel="stylesheet" type="text/css">
           <style type="text/css">
        	#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; width:100%;}
        	/* Add your own Mailchimp form style overrides in your site stylesheet or in this style block.
        	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
        	   #mc_embed_signup {
                    background: unset;
                    clear: left;
                     font: unset; 
                    width: 100%;
                }
                #mc_embed_signup input.email{
                        margin-left: 130px;
                        width:280px !important;
                }
             
         #mc_embed_signup .button {
            float: left !important;
            font-size: 17px;
            border: none;
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 8px;
            letter-spacing: .03em;
            color: #fff;
            background-color: hsla(131.42857142857144, 53.85%, 45.88%, 1.00) !important;
            box-sizing: border-box;
            height: 50px;
            line-height: 32px;
            padding: 0 18px;
            display: inline-block;
            /* margin: 0; */
            transition: all 0.23s ease-in-out 0s;
            margin-top: -50px !important;
            margin-left: -170px !important;
                }
                
                
/*input[type="file"]:before {*/
/*   content: attr(placeholder) !important;*/
/*   color: rgba(0,0,0,.4);*/
/*   display:block;*/
/*   float:right;*/
/* }*/
 input[type='file'] {
  color: transparent;    /* Hides your "No File Selected" */
  direction: rtl;        /* Sets the Control to Right-To-Left */
}
/* input[type='file'] {*/
/*  opacity:0    */
/*}*/
           </style>
      @endsection
@section('content')
  
  <!-- content--->
  <div class="cases-section monthly">
    <div class="row w-row">
        <!-- content page-->
      <div class="column-8 w-clearfix w-col w-col-6"><img src="{{asset('uploads/files/final_monthly.png')}}" alt="" class="image-2">
        <p class="paragraph"> 
  
  الروشتة الشهرية هي خدمة مجانية بالكامل، ستساعدك على طلب روشتتك الشهرية وتحديد موعد شهري لتصلك على عنوانك من أقرب صيدلية لك في الموعد المحدد، بدون أى تكلفة زائدة على سعر الروشتة      </div>
      <!-- /content page--> 
      
      <div class="column-9 w-col w-col-6">
        <h1 data-w-id="664fef2e-c42b-8bb1-6385-95f44b732bfc" class="heading-4"><strong> تسجيل البيانات</strong></h1>
        <div class="w-form">
         <!-- form-->
           @include('website.notfi')
          <form method="post" action="{{ url('monthlypackge') }}" enctype="multipart/form-data"  class="form-2 w-clearfix">
               {{csrf_field()}}
              <input type="text" class="textfield w-input" autofocus="true" maxlength="256" name="name" data-name="name" placeholder="..برجاء ادخال اسمك" id="name-3" required="">
              <input type="email" class="textfield w-input" maxlength="256" name="email" data-name="Email 5" placeholder="..برجاء ادخال بريدك الالكتروني" id="email-5" required="">
              <input type="tel" class="textfield w-input" maxlength="256" onkeypress="return event.charCode >= 48 && event.charCode <= 57" name="phone" data-name="phone" placeholder="..برجاء ادخال رقم الهاتف" id="phone-2" required="">
              <input type="text" class="textfield w-input" maxlength="256" name="address" data-name="address" placeholder="..برجاء ادخال العنوان" id="address-2" required="">
           
              <input type='text' readonly name="date" class='datepicker-here textfield w-input' data-language='en'  placeholder="اختار تاريخ"/>
            
                  <!--<img src="{{asset('chefaa_design/images/none.svg')}}" alt="">-->
               <div class="text-block-14">
                   <label style="float: right; font-family : Tajawal !important;">إرفع الروشتة من هنا</label>
                   <br>
                   <input style="width: 400px;direction: rtl;height: 30px;" name="file" accept="image/x-png,image/gif,image/jpeg" title="ارفع الروشتة " type="file" class="form-control textfield uploader submission-image w-inline-block" placeholder="ارفع روشتتك من هنا" id="Image-URL" href="#" >
                  
               </div>
              
              
              <input  type="submit" value="ارسال" data-wait="..." class="cta smaller w-button month">
          </form>
         <!-- /form-->
        </div>
       
      </div>
    </div>
  </div>
  <!-- /content--> 
  @section('mailchimb')
    <div class="div-block footer">
      <div class="form-block-2 w-form">
        <!--<form id="email-form" name="email-form" data-name="Email Form" class="form">-->
        <!--    <input type="email" class="textfield newsletter w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="..ادخل بريدك الالكتروني" id="email-2" required="">-->
        <!--    <input type="submit" value="ارسال" data-wait="..برجاء الانتظار" class="submit-button w-button">-->
        <!--</form>-->
        <div id="mc_embed_signup">
            <form action="https://chefaa.us18.list-manage.com/subscribe/post?u=0c607300b0650fa81e42606cd&amp;id=3b3b6e768b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate form"  novalidate>
               <div id="mc_embed_signup_scroll">
                    <input type="email" class="textfield newsletter w-input" maxlength="256" name="EMAIL" class="email textfield newsletter w-input" id="mce-EMAIL" data-name="Email 2" placeholder=" ...إدخل بريدك الإلكترونى  " required="">
                    <input type="submit" value="ارسال" data-wait="..برجاء "  name="subscribe" id="mc-embedded-subscribe" class="button submit-button w-bu ">
                </div>
              </form>
        </div>
                        
                        <!--End mc_embed_signup-->
      </div>
      <div class="text-block-7">💌 لمتابعة الجديد من خلال البريد الإلكترونى</div>
    </div>
    
     
  @endsection
   <script>
       $(document).ready(function() {
          $("#mc-embedded-subscribe-form").submit(function() {
                 swal({
                      title: 'شكرا',
                      text: "شكرا لتسجيلك معنا!",
                  });
                location.reload();
                  $.getJSON('http://chefaa.com/cool-cats-optin/mc-end-point.php', formData ,function(data) {
        			// uncomment next line to see your data output in console
        			// console.log(data);
        			
        			// If it worked...
        			if(data.status === 'subscribed') {
        				// Let us know!
        				alert('Thanks!');
        			} else {
        				// Otherwise tell us why it didn't
        				alert("oops error: " + data.detail);
        			}
        		});
          });
        });
    </script>
 <script type="text/javascript">
                        // Initialization
            // $('.datepicker-here').datepicker([options])
            // // Access instance of plugin
            // $('.datepicker-here').data('datepicker')
            $('.datepicker-here').datepicker({
                    language: 'en',
                    minDate: new Date() ,// Now can select only dates, which goes after today
                    dateFormat : 'yyyy-mm-dd',
                })
        </script>
@endsection 