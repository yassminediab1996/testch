<!DOCTYPE html>
<!--  This site was created in Webflow. http://www.webflow.com  -->
<!--  Last Published: Tue Mar 05 2019 19:05:35 GMT+0000 (UTC)  -->
<html data-wf-page="5c6644e8b44ec5d78364cde6" data-wf-site="5c4e31307c1ca4e654061ac3">
<head>
  <meta charset="utf-8">
  <title>تطبيق شفاء</title>
  <meta content="تطبيق شفاء" property="og:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="{{asset('chefaa_design/css/normalize.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('chefaa_design/css/webflow.css')}}" rel="stylesheet" type="text/css">
  <link href="{{asset('chefaa_design/css/chefaa.webflow.css')}}" rel="stylesheet" type="text/css">
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link rel="shortcut icon" href="{{asset('images/icon.png')}}" type="image/x-icon">
    <link rel="icon" href="{{asset('images/icon.png')}}" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('images/icon.png')}}">
    <link rel="apple-touch-icon" href="{{asset('images/icon.png')}}">
</head>
<body>
         <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K7J9NT9');</script>
  <div class="head-green">
    <div data-collapse="medium" data-animation="default" data-duration="400" data-easing="ease-in-quad" data-easing2="ease-in-quad" class="navbar w-nav">
      <div class="navcontainer w-clearfix">
        <div class="menu-button w-nav-button">
          <div class="icon w-icon-nav-menu"></div>
        </div><a href="{{url('/')}}" class="brand w-nav-brand"><img src="{{asset('chefaa_design/images/logo.svg')}}" width="157" alt="" class="logo-white"></a>
        <nav role="navigation" class="nav-menu w-nav-menu">
            <a href="{{url('contact')}}" class="navlink white w-nav-link">تواصل معنا</a>
            <a href="{{url('blog')}}" class="navlink white w-nav-link"> المدونة</a>
            <a href="{{url('chefaa_app')}}" class="navlink white w-nav-link w--current">⚡️ تطبيق شفاء</a>
            <a href="{{url('search')}}" class="navlink white w-nav-link">ابحث عن دواء</a>
            <a href="{{url('store')}}" class="navlink white w-nav-link">المتجر</a>
            <a href="{{url('monthly_subscription')}}" class="navlink white w-nav-link">الروشتة الشهرية</a>
            <a href="#" class="navlink white w-nav-link">المسؤلية المجتمعية</a></nav>
      </div>
    </div>
    <div class="app-head-wrapper">
      <div class="w-row">
        <div class="column-10 w-clearfix w-col w-col-6">
          <div class="div-block-5 div-block-6 white w-clearfix">
            <div class="text-head-container w-clearfix">
              <h1 class="heading white">خدمة <span><strong class="spain white">شفاء</strong></span>الخدمة الأسهل في طلب الدواء</h1>
              <p class="phead white">الأن تستطيع طلب دوائك بكل سهولة ويسر من خلال تطبيق شفاء مع<br>.إمكانية حجز دوائك الشهري ليصلك آينما كنت</p>
              <div class="storecontainer">
                    <a target="_blank" href="https://play.google.com/store/apps/details?id=app.com.chefaa&hl=ar" class="storebutton w-inline-block">
                     <img src="{{asset('chefaa_design/images/googlePlay.svg')}}" alt="" class="playstore"></a>
                  <a target="_blank" href="https://itunes.apple.com/eg/app/chefaa-medicine-delivery/id1438961456?mt=8" class="storebutton w-inline-block">
                      <img src="{{asset('chefaa_design/images/appStore.svg')}}" alt="" class="appstore"></a>
                  </div>
            </div>
          </div>
        </div>
        <div class="w-clearfix w-col w-col-6">
          <div class="iphones-wrapper w-clearfix">
              <img src="{{asset('chefaa_design/images/iPhone_1.png')}}" id="w-node-a175cff103e1-8364cde6" data-w-id="b4e7cd5d-7c08-d7cd-0486-a175cff103e1" alt="" class="image-3">
              <img src="{{asset('chefaa_design/images/iPhone_2.png')}}" id="w-node-898907ebd24f-8364cde6" data-w-id="04471744-e892-9610-e8f8-898907ebd24f" alt="" class="image-4">
              </div>
        </div>
      </div>
    </div>
  </div>
  <div class="b2c-container">
    <h2 class="sectitle center"><strong>مميزات تطبيق شفاء</strong></h2>
    <div class="w-layout-grid b2cgrid">
      <div id="w-node-7fa04097c49f-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/remind.svg')}}" alt=""></div>
        <h4 class="h4"><strong class="bold-text-4">تذكير دوائي</strong></h4>
        <p class="paragraph">مكانية تذكيرك بمواعيد الأدوية من خلال رسائل نصية بالمواعيد التي تحددها.<br></p>
      </div>
      <div id="w-node-7fa04097c4a8-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/payment.svg')}}" alt=""></div>
        <h4 class="h4"><strong>الدفع الإلكترونى</strong></h4>
        <p class="paragraph">إمكانية الدفع من خلال البطاقة الإئتمانية بكل سرية وأمان.<br></p>
      </div>
      <div id="w-node-7fa04097c4b1-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/search.svg')}}" alt=""></div>
        <h4 class="h4"><strong class="bold-text">البحث عن الأدوية</strong></h4>
        <p class="paragraph">  محرك بحث تستطيع من خلاله إيجاد أماكن توافر الدواء بعيدا عن مشاكل البحث المعتاده<br></p>
      </div>
      <div id="w-node-7fa04097c4ba-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/delivery.svg')}}" alt=""></div>
        <h4 class="h4"><strong>توصيل الأدوية</strong></h4>
        <p class="paragraph">توصيل الأدوية من أقرب صيدليه بسهولة ويسر ودقه.<br></p>
      </div>
      <div id="w-node-7fa04097c4c3-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/alert.svg')}}" alt=""></div>
        <h4 class="h4"><strong>تنبيهات النواقص</strong></h4>
        <p class="paragraph">إرسال تنبيهات بنواقص الأدوية الثابتة لأصحاب الأمراض المزمنة<br></p>
      </div>
      <div id="w-node-7fa04097c4cc-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/archive.svg')}}" alt=""></div>
        <h4 class="h4"><strong>أرشيف الطلبات</strong></h4>
        <p class="paragraph">ارشيف كامل لكل طلباتك السابقة يساعدك علي متابعة حالتك.<br></p>
      </div>
      <div id="w-node-7fa04097c4d5-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/offer.svg')}}" alt=""></div>
        <h4 class="h4"><strong>العروض والخصومات</strong></h4>
        <p class="paragraph">إمكانية الوصول لكل العروض والخصومات الخاصة بجميع المنتجات الغير دوائية.<br></p>
      </div>
      <div id="w-node-7fa04097c4de-8364cde6" class="b2c-card">
        <div class="b2c-icon"><img src="{{asset('chefaa_design/images/pckgs.svg')}}" alt=""></div>
        <h4 class="h4"><strong>الباقات الشهرية</strong></h4>
        <p class="paragraph">إمكانية التوصيل الشهري للأدوية بعيدا عن مشاكل نقص الأدوية.<br></p>
      </div>
    </div>
  </div>
  <div class="app-functions">
    <div class="b2c-container appscreens">
      <div data-easing="ease-in-out" data-duration-in="300" data-duration-out="100" class="tabs w-tabs">
        <div class="tabs-menu-2 w-tab-menu">
          <a data-w-tab="feature 1" class="tab-link-tab-1 w-inline-block w-tab-link">
            <div class="tab-head-container w-clearfix"><img src="{{asset('chefaa_design/images/active-icon.svg')}}" alt="" class="feature-app1">
              <div class="text-block-15">فيتشر ١</div>
            </div>
            <p class="paragraph app-feature">إمكانية الوصول لكل العروض والخصومات<br>الخاصة بجميع المنتجات الغير دوائية.<br></p>
          </a>
          <a data-w-tab="feature 2" class="tab-link-tab-1 w-inline-block w-tab-link">
            <div class="tab-head-container inactive w-clearfix"><img src="{{asset('chefaa_design/images/active-icon.svg')}}" alt="" class="feature-app1">
              <div class="text-block-15">فيتشر 2</div>
            </div>
            <p class="paragraph app-feature inactive">إمكانية الوصول لكل العروض والخصومات<br>الخاصة بجميع المنتجات الغير دوائية.<br></p>
          </a>
          <a data-w-tab="feature 3" class="tab-link-tab-1 w-inline-block w-tab-link">
            <div class="tab-head-container inactive w-clearfix"><img src="{{asset('chefaa_design/images/active-icon.svg')}}" alt="" class="feature-app1">
              <div class="text-block-15">فيتشر 3</div>
            </div>
            <p class="paragraph app-feature">إمكانية الوصول لكل العروض والخصومات<br>الخاصة بجميع المنتجات الغير دوائية.<br></p>
          </a>
          <a data-w-tab="feature 4" class="tab-link-tab-1 w-inline-block w-tab-link w--current">
            <div class="tab-head-container inactive w-clearfix"><img src="{{asset('chefaa_design/images/active-icon.svg')}}" alt="" class="feature-app1">
              <div class="text-block-15">فيتشر 4</div>
            </div>
            <p class="paragraph app-feature">إمكانية الوصول لكل العروض والخصومات<br>الخاصة بجميع المنتجات الغير دوائية.<br></p>
          </a>
        </div>
        <div class="tabs-content w-tab-content">
          <div data-w-tab="feature 1" class="w-tab-pane"><img src="{{asset('chefaa_design/images/iPhone_2.png')}}" width="383" alt="" class="feature-1-img"></div>
          <div data-w-tab="feature 2" class="w-tab-pane"><img src="{{asset('chefaa_design/images/iPhone_2.png')}}" width="383" alt="" class="feature-1-img"></div>
          <div data-w-tab="feature 3" class="w-tab-pane"><img src="{{asset('chefaa_design/images/iPhone_2.png')}}" width="383" alt="" class="feature-1-img"></div>
          <div data-w-tab="feature 4" class="w-tab-pane w--tab-active"><img src="{{asset('chefaa_design/images/iPhone_2.png')}}" width="383" alt="" class="feature-1-img"></div>
        </div>
      </div>
    </div>
  </div>
  <footer id="footer" class="footer w-clearfix">
    <div class="div-block footer">
      <div class="form-block-2 w-form">
        <form id="email-form" name="email-form" data-name="Email Form" class="form"><input type="email" class="textfield newsletter w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="..ادخل بريدك الالكتروني" id="email-2" required=""><input type="submit" value="ارسال" data-wait="..برجاء الانتظار" class="submit-button w-button"></form>
        <div class="w-form-done">
          <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
          <div>Oops! Something went wrong while submitting the form.</div>
        </div>
      </div>
      <div class="text-block-7">💌 لمتابعة الجديد من خلال البريد الإلكترونى</div>
    </div>
    <div class="footercontainer w-clearfix">
      <div class="social-icons"><a target="_blank" id="faacebook" href="https://www.facebook.com/GetChefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/fb.svg')}}" alt=""></a><a target="_blank" id="twitter" href="https://www.twitter.com/getchefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/twitter.svg')}}" alt=""></a><a target="_blank" id="instagram" href="https://www.instagram.com/getchefaa/" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/instagram.svg')}}" alt=""></a><a target="_blank" id="linkedin" href="https://www.linkedin.com/company/getchefaa" class="social-icon w-inline-block"><img src="{{asset('chefaa_design/images/linkedin.svg')}}" alt=""></a></div>
      <ol class="list w-list-unstyled">
        <li class="list-item"><a href="#" class="footer-link">تواصل معنا</a></li>
        <li class="list-item"><a href="#" class="footer-link">خدمات</a></li>
        <li class="list-item"><a href="#" class="footer-link">سياسة الخصوصية</a></li>
        <li><a href="#" class="footer-link">استفسارات</a></li>
      </ol>
    </div>
  </footer>
  <script src="https://d1tdp7z6w94jbb.cloudfront.net/js/jquery-3.3.1.min.js" type="text/javascript" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="{{asset('chefaa_design/js/webflow.js')}}" type="text/javascript"></script>
  <!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->
</body>
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'vUqJL7ruiX';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
</html>