<!-- End Content -->

<style>
    .smoke {
        color :white !important;
    }
    .smoke *{
             color :white !important;
    }
    	.list-social>a.twi:hover {
    color: #fff;
    border-color: #1DA1F2;
     background-color: #1DA1F2 !important;
}
.list-social>a.ins:hover {
    color: #fff;
    border-color: pink;
     background-color: pink !important;
}
	.list-social>a.lin:hover {
    color: #fff;
    border-color: #0077B5;
     background-color: #0077B5 !important;
}
	.list-social>a.you:hover {
    color: #fff;
    border-color: red;
     background-color: red !important;
}
.footer01{
         padding-top: 40px !important; 
}
</style>
<div id="footer" >
    <div class=" footer01" style="background-color: #62cb5d !important;">
        <div class="container">
            <div class="footer-list-box">
                <div class="row">
                    <div class="col-md-5 col-sm-12 col-xs-12">
                        <div class="newsletter-form footer-box">
                          
                            <h2 class="title14 white">الاشتراك</h2>
                            <form>
                                <input type="text" onblur="if (this.value=='') this.value = this.defaultValue" onfocus="if (this.value==this.defaultValue) this.value = ''" value="ادخل بريدك الالكترونى">
                                <input type="submit" value="اشتراك" style=" background-color: #4e9b4a !important;">
                            </form>
                          
                        </div>
                        <div class="social-footer footer-box">
                          
                            <h2 class="title14 white">كن على تواصل</h2>
                         
                            <div class="list-social">
                                <a href="https://www.facebook.com/GetChefaa" class="white fac" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://www.twitter.com/getchefaa" class="white  twi" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="https://www.linkedin.com/company/getchefaa" class="white lin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com/getchefaa/" class="white ins" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#" class="white you" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="contact-footer-box footer-box">
                         
                           <h2 class="title14 white">تواصل عنا</h2>
                           <div>
                               <i class="fa fa-map-marker " aria-hidden="true" style="color: white;font-size: 40px;    margin-bottom: -30px;margin-right: -5px;"></i>
                               <p style="color: white; padding-right: 50px;margin-top: -30px;">
                               شارع 151 مبنى 4 الدور التاسع شقة رقم 903 المعادى - القاهرة
                               </p>
                            </div>
                            
                            <div>
                                 <i class="fa fa-mobile-phone" aria-hidden="true" style="color: white;font-size: 40px;    margin-bottom: -30px;margin-right: -3px;"></i>
                                   <p style="color: white; padding-right: 50px;margin-top: -30px;"> 01000644422</p><br>
                            </div>
                            <div>
                                  <i class="fa fa-envelope" style="color: white;font-size: 33px;    margin-bottom: -30px;    margin-right: -10px;"></i>
                            <p style="color: white;    padding-right: 50px;margin-top: -30px;"><a href="mailto:email@demolink.org" class="smoke">info@chefaa.com</a></p>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer List Box -->
        </div>
       
        <!-- End Payment -->
        
        <!-- End Footer Tab -->
        <div class="footer-copyright" style="background-color: #4e9b4a !important;">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12">
                        <p class="copyright" style="    text-align: center;
    margin-right: 310px;">جميع الحقوق محفوظه لشفاء.</p>
                    </div>
                 
                </div>
            </div>
        </div>
        <!-- End Footer Copyright -->
    </div>
</div>

	<a href="#" class="radius scroll-top style1"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
</div>
<script src="{{asset('website/js/libs/jquery-3.2.1.min.js')}}"></script>
<script src="{{asset('website/js/libs/bootstrap.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.fancybox.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery-ui.min.js')}}"></script>
<script src="{{asset('website/js/libs/owl.carousel.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.jcarousellite.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.elevatezoom.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script src="{{asset('website/js/libs/timecircles.min.js')}}"></script>
<script src="{{asset('website/js/libs/popup.js')}}"></script>
<script src="{{asset('website/js/libs/wow.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script src="{{asset('website/js/libs/flipclock.min.js')}}"></script>
<script src="{{asset('website/js/theme.js')}}"></script>



<!-- Hotjar Tracking Code for www.chefaa.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- Hotjar Tracking Code for www.chefaa.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'vUqJL7ruiX';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
<!-- {/literal} END JIVOSITE CODE -->
</body>
</html>