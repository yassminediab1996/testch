<!-- End Content -->

<style>
 
    .smoke {
        color :white !important;
    }
    .smoke *{
             color :white !important;
    }
    p{
        color:white !important;
           font-family : Tajawal !important;
               font-size: 11pt !important;
        margin-bottom: 35px !important;
        display:inline-block;
       /* float: right;*/
    }
  
    h2{
          color:white !important;
            font-family : Tajawal !important;
                font-size: 17px;
                font-weight:500;
    }
    i{
        color :white !important;
            margin-bottom: 20px !important;

    }
     @font-face{
            font-family: 'Tajawal';
            src: url({{ url('Tajawal-Regular.ttf') }});
            }
            .h{
                    text-align: right !important;
                     font-family : Tajawal !important;
            }
    @media (min-width: 1200px){
        .tt {
             margin: 0 !important;
        }
    }
@media only screen and (min-width: 992px) {
    .tt{
             margin-right: 0px !important; 
    }
}
@media only screen and (min-width: 600px) {
     .tt{
             margin-right: 0px !important; 
    }
}
 	.list-social>a.twi:hover {
    color: #fff;
    border-color: #1DA1F2;
     background-color: #1DA1F2 !important;
}
.list-social>a.ins:hover {
    color: #fff;
    border-color: pink;
     background-color: pink !important;
}
	.list-social>a.lin:hover {
    color: #fff;
    border-color: #0077B5;
     background-color: #0077B5 !important;
}
	.list-social>a.you:hover {
    color: #fff;
    border-color: red;
     background-color: red !important;
}
</style>
<div id="footer" >
    <div class="" style="background-color: #62cb5d !important;padding-top: 20px;">
        <div class="container">
                <div class="row" style="margin-bottom: 20px;">
                  <div class="col-md-5 col-sm-12 col-xs-12" style="margin: 0 !important;">
                         <h2 style="text-align:right">الاشتراك</h2>
                         <div class="newsletter-form footer-box">
                         
                            <form style="margin-right: 0;">
                                <input type="text" onblur="if (this.value=='') this.value = this.defaultValue" onfocus="if (this.value==this.defaultValue) this.value = ''" value="ادخل بريدك الالكترونى">
                                <input type="submit" value="اشتراك" style=" background-color: #4e9b4a !important;">
                            </form>
                    
                         </div>
                            <h2 style="text-align:right" >كن على تواصل</h2>
                         <div class="social-footer footer-box" style=" width: 240px;margin-right: 0;">
                        
                           <div class="list-social">
                                <a href="https://www.facebook.com/GetChefaa" class="white fa" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://www.twitter.com/getchefaa" class="white twi" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="https://www.linkedin.com/company/getchefaa" class="white lin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com/getchefaa/" class="white ins" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#" class="white you" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                           </div>
                         </div>
                  </div>
                  
                  <div class="col-md-3 col-sm-6 col-xs-12" style="margin: 0 !important;">
                      <h2 class="h">تواصل معنا</h2>
                      <div class="row">
                         <div class="col-md-3 col-sm-3 col-xs-3 col-lg-2 tt" style="width: 30px;padding: 10px;margin-bottom: 15px;margin-left: 0;/* margin-right: 0; */">

                              <i class="fa fa-map-marker " aria-hidden="true" style="color: white;font-size: 40px;  "></i>
                              <i class="fa fa-mobile-phone" aria-hidden="true" style="color: white;font-size: 40px; "></i>
                              <i class="fa fa-envelope" style="color: white;font-size: 33px;"></i>
                        </div>
                    
                  
                        <div class="col-md-9 col-sm-9 col-xs-9 col-lg-10 tt" style="padding-top: 19px;margin-right: 13px;text-align: right;">
                               <p style="color: white; ">
                                   شارع 151 مبنى 4 الدور التاسع شقة رقم 903 المعادى - القاهرة
                                   </p><br>
                               <p style="color: white; "> 01000644422</p><br>
                               <p style="color: white;"><a href="mailto:email@demolink.org" class="smoke">info@chefaa.com</a></p><br>
                    
                        </div>
                        </div>
                    
                  </div>
                </div>
          
        </div>

        
        <!-- End Footer Tab -->
        <div class="footer-copyright" style="background-color: #4e9b4a !important;    height: 60px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12">
                        <p class="copyright" >جميع الحقوق محفوظة لشفاء .</p>
                    </div>
                 
                </div>
            </div>
        </div>
        <!-- End Footer Copyright -->
    </div>
</div>

	<a href="#" class="radius scroll-top style1"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
</div>
<script src="{{asset('website/js/libs/jquery-3.2.1.min.js')}}"></script>
<script src="{{asset('website/js/libs/bootstrap.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.fancybox.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery-ui.min.js')}}"></script>
<script src="{{asset('website/js/libs/owl.carousel.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.jcarousellite.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.elevatezoom.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script src="{{asset('website/js/libs/timecircles.min.js')}}"></script>
<script src="{{asset('website/js/libs/popup.js')}}"></script>
<script src="{{asset('website/js/libs/wow.min.js')}}"></script>
<script src="{{asset('website/js/libs/jquery.mCustomScrollbar.min.js')}}"></script>
<script src="{{asset('website/js/libs/flipclock.min.js')}}"></script>
<script src="{{asset('website/js/theme.js')}}"></script>




<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-B7JP2KV');</script>
<!-- End Google Tag Manager -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-B7JP2KV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Hotjar Tracking Code for www.chefaa.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- Hotjar Tracking Code for www.chefaa.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1093439,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'vUqJL7ruiX';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
<!-- {/literal} END JIVOSITE CODE -->
</body>
</html>